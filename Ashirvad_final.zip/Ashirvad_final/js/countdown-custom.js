jQuery(document).ready(function() {
        $(function () {
            $('#defaultCountdown').countdown({until: new Date(2022, 8, 10, 8)}); // year, month, date, hour
        });
});		

